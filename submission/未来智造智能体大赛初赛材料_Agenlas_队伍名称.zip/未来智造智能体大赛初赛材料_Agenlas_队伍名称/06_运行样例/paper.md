# Checking Citations with Lexical Retrieval: A Small Baseline Study

## Abstract
Prior work reports that cited sources are often wrong in model-written text [A2]. We ask how far a lexical retriever goes in matching a citing sentence to its source. On 24 real arXiv abstracts, TF-IDF ranks the true source first for 0.958 of queries (MRR 0.979) against 0.792 for word overlap (MRR 0.868) [A6].

## Method
Each paper title is used as a query against all abstracts in the corpus [A2]. We compare TF-IDF cosine similarity with Jaccard word overlap and report recall at rank one and mean reciprocal rank [A6].

## Results
On 24 real arXiv abstracts, TF-IDF ranks the true source first for 0.958 of queries (MRR 0.979) against 0.792 for word overlap (MRR 0.868) [A6].

## Limitations
Titles share vocabulary with their own abstracts, so this setting is easier than real citing sentences. The corpus is small and comes from three keyword searches.